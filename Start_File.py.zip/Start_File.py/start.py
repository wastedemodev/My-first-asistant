import speech_recognition
from pygame import mixer
import time
import pygame
import wikipedia
sr=speech_recognition.Recognizer()
sr.pause_threshold = 0.7
wikipedia.set_lang("Ru")
def main():  
    try: 
        print("say some thing:\n")  
        with speech_recognition.Microphone() as mic:
            sr.adjust_for_ambient_noise(source=mic,duration=0.7)
            audio = sr.listen(source=mic)
            query = sr.recognize_google(audio_data=audio,language='ru-RU').lower()
        return query
    except:
        print("я не понял что ты сказал")
query=main()
print('You say:' + query)

pygame.mixer.init()
mixer.music.set_volume(10)
pygame.mixer.music.play("Start_File/ok2.wav")
try:    
    
    print(wikipedia.summary(query))
    for i in range(1):
        break
        
except:
    print('doesnt foud')
    

if __name__=="__main__":
    main()